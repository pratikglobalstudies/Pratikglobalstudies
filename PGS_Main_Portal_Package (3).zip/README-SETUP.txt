PGS MAIN PORTAL - GITHUB PAGES SETUP

Folder structure:
- index.html (main home page)
- School/index.html (existing school website)
- PGS-Pharma/index.html (standalone pharmacy website)
- Competitive-Exams/index.html (government competitive exam page)

Upload these files/folders into the ROOT of your existing repository:
pratikglobalstudies/Pratikglobalstudies

Do not upload the outer PGS_Main_Portal_Package folder itself. Open it and upload index.html plus the three folders. Keep the repository's existing assets and files.

After commit, the expected links are:
Main: https://pratikglobalstudies.github.io/Pratikglobalstudies/
School: https://pratikglobalstudies.github.io/Pratikglobalstudies/School/
Pharma: https://pratikglobalstudies.github.io/Pratikglobalstudies/PGS-Pharma/
Competitive Exams: https://pratikglobalstudies.github.io/Pratikglobalstudies/Competitive-Exams/

Note: Passwords in front-end JavaScript are only basic convenience locks, not secure access control.
